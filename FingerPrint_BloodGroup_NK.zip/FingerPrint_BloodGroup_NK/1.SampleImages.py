﻿import cv2
from matplotlib import pyplot as plt
Image1 = cv2.imread('./DB1_B/AVe/101_1.tif')
Image2 = cv2.imread('./DB1_B/AVe/101_2.tif')
Image3 = cv2.imread('./DB1_B/AVe/101_3.tif')
Image4 = cv2.imread('./DB1_B/AVe/101_4.tif')
#fig, ax = plt.subplots(figsize=(4, 4))
#im = ax.imshow(Image1)#,cmap=plt.get_cmap('hot'), interpolation='nearest',               vmin=0, vmax=1)
#fig.colorbar(im)
rows = 4
columns =4

fig = plt.figure(figsize=(8, 8))
fig.add_subplot(rows, columns, 1)
plt.imshow(Image1)
plt.axis('off')
plt.title("A+Ve: One")
fig.add_subplot(rows, columns, 2)
plt.imshow(Image2)
plt.axis('off')
plt.title("Two")
fig.add_subplot(rows, columns, 3)
plt.imshow(Image3)
plt.axis('off')
plt.title("Three")
fig.add_subplot(rows, columns, 4)
plt.imshow(Image4)
plt.axis('off')
plt.title("Four")

#plt.axis('off')

Image1 = cv2.imread('./DB1_B/AVe/101_5.tif')
Image2 = cv2.imread('./DB1_B/AVe/101_6.tif')
Image3 = cv2.imread('./DB1_B/AVe/101_7.tif')
Image4 = cv2.imread('./DB1_B/AVe/101_8.tif')
#plt.title("Training Data Tumor (No) First")
fig.add_subplot(rows, columns, 9)
plt.imshow(Image1)
plt.axis('off')
plt.title("Five")
fig.add_subplot(rows, columns, 10)
plt.imshow(Image2)
plt.axis('off')
plt.title("Six")
fig.add_subplot(rows, columns, 11)
plt.imshow(Image3)
plt.axis('off')
plt.title("Seven")
fig.add_subplot(rows, columns, 12)
plt.imshow(Image4)
plt.axis('off')
plt.title("Eight")



plt.show()
#plt.title('YES')


#exit()


#plt.imshow(Image1)
# create figure
#fig = plt.figure(figsize=(4, 4))
  
# setting values to rows and column variables

  
# reading images


import cv2
from matplotlib import pyplot as plt
Image1 = cv2.imread('./DB1_B/A-Ve/102_1.tif')
Image2 = cv2.imread('./DB1_B/A-Ve/102_2.tif')
Image3 = cv2.imread('./DB1_B/A-Ve/102_3.tif')
Image4 = cv2.imread('./DB1_B/A-Ve/102_4.tif')
#fig, ax = plt.subplots(figsize=(4, 4))
#im = ax.imshow(Image1)#,cmap=plt.get_cmap('hot'), interpolation='nearest',               vmin=0, vmax=1)
#fig.colorbar(im)
rows = 4
columns =4

fig = plt.figure(figsize=(8, 8))
fig.add_subplot(rows, columns, 1)
plt.imshow(Image1)
plt.axis('off')
plt.title("A-Ve: One")
fig.add_subplot(rows, columns, 2)
plt.imshow(Image2)
plt.axis('off')
plt.title("Two")
fig.add_subplot(rows, columns, 3)
plt.imshow(Image3)
plt.axis('off')
plt.title("Three")
fig.add_subplot(rows, columns, 4)
plt.imshow(Image4)
plt.axis('off')
plt.title("Four")

#plt.axis('off')

Image1 = cv2.imread('./DB1_B/A-Ve/102_5.tif')
Image2 = cv2.imread('./DB1_B/A-Ve/102_6.tif')
Image3 = cv2.imread('./DB1_B/A-Ve/102_7.tif')
Image4 = cv2.imread('./DB1_B/A-Ve/102_8.tif')
#plt.title("Training Data Tumor (No) First")
fig.add_subplot(rows, columns, 9)
plt.imshow(Image1)
plt.axis('off')
plt.title("Five")
fig.add_subplot(rows, columns, 10)
plt.imshow(Image2)
plt.axis('off')
plt.title("Six")
fig.add_subplot(rows, columns, 11)
plt.imshow(Image3)
plt.axis('off')
plt.title("Seven")
fig.add_subplot(rows, columns, 12)
plt.imshow(Image4)
plt.axis('off')
plt.title("Eight")



plt.show()
#plt.title('YES')


#exit()


#plt.imshow(Image1)
# create figure
#fig = plt.figure(figsize=(4, 4))
  
# setting values to rows and column variables

import cv2
from matplotlib import pyplot as plt
Image1 = cv2.imread('./DB1_B/BVe/103_1.tif')
Image2 = cv2.imread('./DB1_B/BVe/103_2.tif')
Image3 = cv2.imread('./DB1_B/BVe/103_3.tif')
Image4 = cv2.imread('./DB1_B/BVe/103_4.tif')
#fig, ax = plt.subplots(figsize=(4, 4))
#im = ax.imshow(Image1)#,cmap=plt.get_cmap('hot'), interpolation='nearest',               vmin=0, vmax=1)
#fig.colorbar(im)
rows = 4
columns =4

fig = plt.figure(figsize=(8, 8))
fig.add_subplot(rows, columns, 1)
plt.imshow(Image1)
plt.axis('off')
plt.title("B+Ve: One")
fig.add_subplot(rows, columns, 2)
plt.imshow(Image2)
plt.axis('off')
plt.title("Two")
fig.add_subplot(rows, columns, 3)
plt.imshow(Image3)
plt.axis('off')
plt.title("Three")
fig.add_subplot(rows, columns, 4)
plt.imshow(Image4)
plt.axis('off')
plt.title("Four")

#plt.axis('off')

Image1 = cv2.imread('./DB1_B/BVe/103_5.tif')
Image2 = cv2.imread('./DB1_B/BVe/103_6.tif')
Image3 = cv2.imread('./DB1_B/BVe/103_7.tif')
Image4 = cv2.imread('./DB1_B/BVe/103_8.tif')
#plt.title("Training Data Tumor (No) First")
fig.add_subplot(rows, columns, 9)
plt.imshow(Image1)
plt.axis('off')
plt.title("Five")
fig.add_subplot(rows, columns, 10)
plt.imshow(Image2)
plt.axis('off')
plt.title("Six")
fig.add_subplot(rows, columns, 11)
plt.imshow(Image3)
plt.axis('off')
plt.title("Seven")
fig.add_subplot(rows, columns, 12)
plt.imshow(Image4)
plt.axis('off')
plt.title("Eight")



plt.show()
#plt.title('YES')


exit()
