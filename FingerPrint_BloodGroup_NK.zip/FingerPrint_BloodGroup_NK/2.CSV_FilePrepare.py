import sys
import os
import cv2
import imutils
#from scipy.misc import imread
from scipy.linalg import norm
from numpy import sum, average
from matplotlib.pyplot import imread



def to_grayscale(arr):
    "If arr is a color image (3D array), convert it to grayscale (2D array)."
    if len(arr.shape) == 3:
        return average(arr, -1)  # average over the last axis (color channels)
    else:
        return arr

def normalize(arr):
    rng = arr.max()-arr.min()
    amin = arr.min()
    return (arr-amin)*255/rng



"""
img = cv2.imread("./dataset/training_set/yes/y1.jpg", 0) #since the image is grayscale, we need only one channel and the value '0' indicates just that

for i in range (img.shape[0]): #traverses through height of the image
    for j in range (img.shape[1]): #traverses through width of the image
        #print (img[i][j])

siz= img.shape[0] * img.shape[1]
print (siz)
"""




#print (files)

#file1 = 'sample.png'    
#img1 = to_grayscale(imread(file1).astype(float))
i=1
dim=[100,100]
#img1 = cv2.resize(img1, dim, interpolation = cv2.INTER_AREA)


#Creating training data - pixel values of yes images to csv file
file1 = open("fingerprint_train.csv","w")
st1 ="label,"
for i in range(1,10001):
 st1=st1+ 'pixel' + str(i) + ","

#Write header line
st1=st1+ 'Group,'
st1=st1[:-1]
file1.write(st1 + '\n')
#======
#--------------------------------------
files=os.listdir('./DB1_B/AVe')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/yes/" + f)
  #img=to_grayscale(imread('./DB1_B/AVe/'+ f).astype(float))
  img=imread('./DB1_B/AVe/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#imutils.resize(img, width=100,height=96) #cv2.resize(img, dim)#, interpolation = cv2.INTER_AREA)
  siz= img.shape[0] * img.shape[1]
  #print(img.shape[0] )
  #print(img.shape[1])
  #print(siz)
  #exit()
  print(cnt)
  print('Reading File' + f)
  st1='1,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "A+Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#file1.close()


#Creating training data - pixel values of no images to csv file
#file1 = open("braintumor_train.csv","a")

files=os.listdir('./DB1_B/A-Ve')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/no/" + f)
  #img=to_grayscale(imread('./DB1_B/A-Ve/'+ f).astype(float))
  img=imread('./DB1_B/A-Ve/'+ f,0)#.astype(float))).astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='0,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "A-Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#----------------------------------------------
#--------------------------------------
files=os.listdir('./DB1_B/BVe')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/yes/" + f)
  #img=to_grayscale(imread('./DB1_B/BVe/'+ f).astype(float))
  img=imread('./DB1_B/BVe/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='1,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "B+Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#file1.close()


#Creating training data - pixel values of no images to csv file
#file1 = open("braintumor_train.csv","a")

files=os.listdir('./DB1_B/B-Ve')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/no/" + f)
  #img=to_grayscale(imread('./DB1_B/B-Ve/'+ f).astype(float))
  img=imread('./DB1_B/B-Ve/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  #img = cv2.resize(img, dim)#, interpolation = cv2.INTER_AREA)
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='0,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "B-Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#----------------------------------------------
  
  #--------------------------------------
files=os.listdir('./DB1_B/OVe')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/yes/" + f)
  #img=to_grayscale(imread('./DB1_B/OVe/'+ f).astype(float))
  img=imread('./DB1_B/OVe/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='1,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "O+Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#file1.close()


#Creating training data - pixel values of no images to csv file
#file1 = open("braintumor_train.csv","a")

files=os.listdir('./DB1_B/O-Ve')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/no/" + f)
  #img=to_grayscale(imread('./DB1_B/O-Ve/'+ f).astype(float))
  img=imread('./DB1_B/O-Ve/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='0,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "O-Ve, "
  st1=st1[:-1]
  file1.write(st1 + '\n')

#----------------------------------------------
  
  #--------------------------------------
files=os.listdir('./DB1_B/ABVe')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/yes/" + f)
  #img=to_grayscale(imread('./DB1_B/ABVe/'+ f).astype(float))
  img=imread('./DB1_B/ABVe/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='1,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "AB+Ve,"
  st1=st1[:-1]
  file1.write(st1 + '\n')

#file1.close()


#Creating training data - pixel values of no images to csv file
#file1 = open("braintumor_train.csv","a")

files=os.listdir('./DB1_B/AB-Ve')
cnt=0
st1=''
for f in files : #i in range(1,10):
  st1=''
  #if (cnt==2):
  #   break
  cnt=cnt+1
  #print(os.path.dirname(__file__) + "/dataset/training_set/no/" + f)
  #img=to_grayscale(imread('./DB1_B/AB-Ve/'+ f).astype(float))
  img=imread('./DB1_B/AB-Ve/'+ f,0)#.astype(float))
  img =cv2.resize(img, (100,100))#img =imutils.resize(img, width=100,height=100) #cv2.resize(img, dim)#,
  siz= img.shape[0] * img.shape[1]
  print(cnt)
  print('Reading File' + f)
  st1='0,'
  for i in range(0,img.shape[0]):
     for j in range(0,img.shape[1]):
           #print( int(img[i,j]),sep=' ')
           st1=st1 + str(int(img[i,j])) +','
  print()
  st1=st1 + "AB-Ve,"
  st1=st1[:-1]
  file1.write(st1 + '\n')

#----------------------------------------------
  
  
  

file1.close()







#====================END

"""       # read images as 2D arrays (convert to grayscale for simplicity)
       
       #img2 = to_grayscale(imread(file2).astype(float))
       #img2 = to_grayscale(files[i]).astype(float))
       # compare
       n_m, n_0 = compare_images(img1, img2)
       print('Compare File : ' , i) 
       i=i+1
       print(f)
       print(n_m)
       #print(img1.size)
       print ("Manhattan norm:", n_m, "/ per pixel:", n_m/img1.size)
       #print ("Zero norm:", n_0, "/ per pixel:", n_0*1.0/img1.size)
"""




"""

def compare_images(img1, img2):
    # normalize to compensate for exposure difference, this may be unnecessary
    # consider disabling it
    img1 = normalize(img1)
    img2 = normalize(img2)
    # calculate the difference and its norms
    diff = img1 - img2  # elementwise for scipy arrays
    #print('Diff',diff)
    m_norm = sum(abs(diff))  # Manhattan norm
    z_norm = norm(diff.ravel(), 0)  # Zero norm
    return (m_norm, z_norm)

"""
