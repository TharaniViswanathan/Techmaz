(function(networkId) {
var cacheLifetimeDays = 1;

var customDataWaitForConfig = [
  { on: function() { return Invoca.Client.parseCustomDataField("ab_test", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDatalayerLookup(\"abtests\")"); }, paramName: "ab_test", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDataLayerLookup(\"campaign\",ctcaDataLayer)"); }, paramName: "campaign", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("channel", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDataLayerLookup(\"channel\",ctcaDataLayer)"); }, paramName: "channel", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("content", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDataLayerLookup(\"content\",ctcaDataLayer)"); }, paramName: "content", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("ctcavisitorid", "Unique", "Cookie", "ctcavisitorid"); }, paramName: "ctcavisitorid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("current_page", "Last", "JavascriptDataLayer", "document.URL"); }, paramName: "current_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("current_path", "Last", "JavascriptDataLayer", "encodeURI(window.location.pathname)"); }, paramName: "current_path", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("dc_id", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"site_ids\",\"dc_id\")"); }, paramName: "dc_id", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("dstrackerid", "Last", "URLParam", "dstrackerid"); }, paramName: "dstrackerid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("entry_page", "Last", "JavascriptDataLayer", "encodeURIComponent(Invoca.Client.getEntryPage())"); }, paramName: "entry_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("gclid", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"site_ids\",\"gclid\")"); }, paramName: "gclid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("g_cid", "Last", "JavascriptDataLayer", "Invoca.Client.invocaGetGCID()"); }, paramName: "g_cid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("host", "Last", "JavascriptDataLayer", "location.hostname"); }, paramName: "host", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("kuid", "Last", "JavascriptDataLayer", "window.localStorage.kxctca_kuid"); }, paramName: "kuid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("kxctca_segs", "Last", "JavascriptDataLayer", "window.localStorage.kxctca_segs"); }, paramName: "kxctca_segs", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("kxctca_segs_partner", "Last", "JavascriptDataLayer", "window.localStorage.kxctca_segs"); }, paramName: "kxctca_segs_partner", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("medium", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDataLayerLookup(\"medium\",ctcaDataLayer)"); }, paramName: "medium", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("msclkid", "Last", "URLParam", "msclkid"); }, paramName: "msclkid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("referrer", "Last", "Cookie", "session_referrer"); }, paramName: "referrer", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("referring_domain", "Last", "JavascriptDataLayer", "Invoca.Client.getReferrerDomain()"); }, paramName: "referring_domain", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("session_campaign", "Last", "JavascriptDataLayer", "Invoca.JSON.parse(decodeURIComponent(Invoca.Tools.readCookie(\"session_campaign\")))"); }, paramName: "session_campaign", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("site_activities", "Last", "JavascriptDataLayer", "Invoca.JSON.parse(decodeURIComponent(window.localStorage.ctca_site_activities))"); }, paramName: "site_activities", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("site_interests", "Last", "JavascriptDataLayer", "Invoca.JSON.parse(decodeURIComponent(window.localStorage.ctca_site_interests))"); }, paramName: "site_interests", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("site_promotions", "Last", "JavascriptDataLayer", "Invoca.JSON.parse(decodeURIComponent(Invoca.Tools.readCookie(\"site_promotions\")))"); }, paramName: "site_promotions", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("source", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaDataLayerLookup(\"source\",ctcaDataLayer)"); }, paramName: "source", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("source_code", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaMarketingCampaignLookup('sourcecode', 'invsrc')"); }, paramName: "source_code", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_adg", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_adg\")"); }, paramName: "t_adg", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_ag", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_ag\")"); }, paramName: "t_ag", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_aud", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_aud\")"); }, paramName: "t_aud", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_bud", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_bud\")"); }, paramName: "t_bud", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_cam", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_cam\")"); }, paramName: "t_cam", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_ch", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_ch\")"); }, paramName: "t_ch", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_con", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_con\")"); }, paramName: "t_con", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_ctv", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_ctv\")"); }, paramName: "t_ctv", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_d", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_d\")"); }, paramName: "t_d", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_dur", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_dur\")"); }, paramName: "t_dur", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_med", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_med\")"); }, paramName: "t_med", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_mkt", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_mkt\")"); }, paramName: "t_mkt", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_mod", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_mod\")"); }, paramName: "t_mod", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_mtp", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_mtp\")"); }, paramName: "t_mtp", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_plc", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_plc\")"); }, paramName: "t_plc", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_pos", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_pos\")"); }, paramName: "t_pos", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_pur", "Last", "JavascriptDataLayer", "Invoca.Client.ctcaMarketingCampaignLookup('purpose', 't_pur')"); }, paramName: "t_pur", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_re", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_re\")"); }, paramName: "t_re", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_si", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_si\")"); }, paramName: "t_si", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_src", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_src\")"); }, paramName: "t_src", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_st", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_st\")"); }, paramName: "t_st", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_sz", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_sz\")"); }, paramName: "t_sz", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_tac", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_tac\")"); }, paramName: "t_tac", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_tar", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_tar\")"); }, paramName: "t_tar", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("t_trm", "Last", "JavascriptDataLayer", "Invoca.Client.invocaReadCookieArray(\"session_campaign\",\"t_trm\")"); }, paramName: "t_trm", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("ua", "Last", "JavascriptDataLayer", "window.navigator.userAgent"); }, paramName: "ua", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_campaign", "Last", "URLParam", "utm_campaign"); }, paramName: "utm_campaign", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_content", "Last", "URLParam", "utm_content"); }, paramName: "utm_content", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_medium", "Last", "URLParam", "utm_medium"); }, paramName: "utm_medium", fallbackValue: function() { return Invoca.PNAPI.currentPageSettings.poolParams.utm_medium || null; } },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_source", "Last", "URLParam", "utm_source"); }, paramName: "utm_source", fallbackValue: function() { return Invoca.PNAPI.currentPageSettings.poolParams.utm_source || null; } },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_term", "Last", "URLParam", "utm_term"); }, paramName: "utm_term", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("visitor_type", "Last", "JavascriptDataLayer", "Invoca.Client.visitorType()"); }, paramName: "visitor_type", fallbackValue: null }
];

var defaultCampaignId = null;

var destinationSettings = {
  paramName: null
};

var numbersToReplace = {
  "+18473366111": "gurnee_care_center",
  "+18479865352": "non_oncology_chicago",
  "+13128152733": "non_oncology_downtown_chicago",
  "+18479865353": "non_oncology_gurnee",
  "+12155376637": "lymphedema_clinic_philadelphia",
  "+16789495176": "hyperlocal_atlanta",
  "+18479860415": "hyperlocal_chicago",
  "+13128746789": "hyperlocal_downtown_chicago",
  "+14806642664": "hyperlocal_gilbert",
  "+18479860417": "hyperlocal_gurnee",
  "+16236665619": "hyperlocal_north_phoenix",
  "+12673100258": "hyperlocal_philadelphia",
  "+16237381552": "hyperlocal_phoenix",
  "+14808407299": "hyperlocal_scottsdale",
  "+19189929269": "hyperlocal_tulsa"
};

var organicSources = true;

var reRunAfter = 3000;

var requiredParams = null;

var resetCacheOn = ['gclid', 'utm_source', 'utm_medium', 'invsrc', 't_ch'];

var waitFor = 0;

var customCodeIsSet = (function() {
  Invoca.Client.customCode = function(options) {
    /****************************************** CTCA Invoca Custom Solution * **************************************/

//CTCA MarketingCampaign Lookup Function
Invoca.Client.ctcaMarketingCampaignLookup = function (markeingFieldName, urlparameter1, urlparameter2){
  
    //Set up the clean variable and object for future use
 	var marketingFieldValue = "na";   
	var campaignObj = "";
    //For loop to look for the fieldName match
	for(var i=0; i<ctcaDataLayer.length; i++){
		if(ctcaDataLayer[i].marketingCampaign){
			 campaignObj = ctcaDataLayer[i].marketingCampaign;
			 break;
        }
    }
    //Assign the marketing campaign value
	if(campaignObj[markeingFieldName]){
      
      		marketingFieldValue = campaignObj[markeingFieldName];

    }
    //Else if the cookie does exist
    else if(Invoca.Tools.readCookie('session_campaign')){
 			//Return the cookie value         
     		marketingFieldValue = Invoca.JSON.parse(decodeURIComponent(Invoca.Tools.readCookie('session_campaign')))[markeingFieldName];
    }
    //Else, look for first url parameters instead
    else if(ctcaGetQueryString(urlparameter1,document.location.href, 1)){
    		marketingFieldValue = ctcaGetQueryString(urlparameter1, document.location.href, 1)
    }
    else{
    		marketingFieldValue = ctcaGetQueryString(urlparameter2, document.location.href, 1)
    }
	return marketingFieldValue;
    }
//CTCA Datalayer Function
Invoca.Client.ctcaDatalayerLookup = function(layername){
   
    //For loop to look for the fieldName match
	  for(var i=0; i<ctcaDataLayer.length; i++){
	    var layerObj = ctcaDataLayer[i];
		  if(layerObj[layername]){
			   return JSON.stringify(layerObj);
      }
    }
    return;
}



 // Custom Function to Read CTCA Cookie
Invoca.Client.invocaReadCookieArray = function(cName, aName){
	var cookieStr = decodeURIComponent(Invoca.Tools.readCookie(cName));
    var attributeTxt = "na";

	if(cookieStr){
		var cookieArr = Invoca.JSON.parse(cookieStr);
		if(cookieArr) attributeTxt = decodeURIComponent(cookieArr[aName]);
    }

	return attributeTxt;
};

//Get referring domain host
Invoca.Client.getReferrerDomain = function() {
    var url = document.createElement('a');
	  url.href = decodeURIComponent(Invoca.Tools.readCookie("session_referrer"));

	  if(url.href.indexOf("cancercenter.com") === -1 && url.href.indexOf("invoca.net") === -1) {
		  return url.hostname;
      }
	  else{ 
		  return "";
      }
};

//Get referring domain host
Invoca.Client.getEntryPage = function() {
    var url  = decodeURIComponent(Invoca.Tools.readCookie("session_entry_page_url"));
    var path = '';

    if(url){
      var urlParts = url.replace('http://','').replace('https://','').replace('?','.com').split('.com');
      
      path = urlParts[1];
    }
    
    return path;
	 
};

//New or Repeat Visitor
Invoca.Client.visitorType = function(){
	var sessionCnt = parseInt(Invoca.Client.invocaReadCookieArray("site_activities","session_counter"));
	var visitorTypeName = "New";

	if(window.localStorage){
	var ctca_site_activities = decodeURIComponent(localStorage.getItem("ctca_site_activities"));
	visitorTypeName = Invoca.JSON.parse(ctca_site_activities).vistor_type;
  } 
    

	return visitorTypeName;
};

//CTCA Data Layer Lookup Function
//Maybe deprecated, need a new function 08072020 - AX
Invoca.Client.ctcaDataLayerLookup = function (fieldName, dl){
 	var fieldValue = "na";   
	var campaignObj = "";
  
  //Make sure fields exists and are valid
	if(typeof(fieldName) !== "string") return "na";
	if(typeof(dl) !== "object") return "na";

	for(var i=0; i<dl.length; i++){
		if(dl[i].marketingCampaign){
			 campaignObj = dl[i].marketingCampaign;
			 break;
        }
    }

	if(campaignObj[fieldName]) fieldValue = campaignObj[fieldName];

	return fieldValue;
};

//GCID
Invoca.Client.invocaGetGCID =function(){
  var gcid, gcidCookie;
  
  //GA object stores client ID
  if(ga){
	  var trackers = ga.getAll();
	  var i, len;
	  for (i = 0, len = trackers.length; i < len; i += 1) {
   		  if (trackers[i].get('trackingId') === 'UA-39238626-4') {
     		  gcid = trackers[i].get('clientId');
   		  	}
		  }
   
    // If GA menthod fails, try reading cookie
	  if(!gcid){
		  gcidCookie = Invoca.Tools.readCookie('_ga');
		  if(gcidCookie){
			  gcid = gcidCookie.split('.')[2]+'.'+gcidCookie.split('.')[3];
    	  	}
		  }
    
    //If all else fails try reading the site ids cookie
	  if(!gcid){
		  gcid = Invoca.JSON.parse(decodeURIComponent(Invoca.Tools.readCookie('site_ids'))).gcid;
      }
    }
  
  //If GA object is not available
  else{
    
    //Read GA Cookie
  	gcidCookie = decodeURIComponent(Invoca.Tools.readCookie('_ga'));
  	if(gcidCookie){
		  gcid = gcidCookie.split('.')[2]+'.'+gcidCookie.split('.')[3];
      }
    
    //Read Site IDs Cookie
  	if(!gcid){
		  gcid = Invoca.JSON.parse(decodeURIComponent(Invoca.Tools.readCookie('site_ids'))).gcid;
      }
  }

  //pass in na if not found
  if(!gcid) gcid = 'na';
  
  return gcid;
};

//Number adnimation - Fade
function fadeNumber(mapping) {
  $(".invTelNum").animate({opacity: 1}, 2000);
} 

 //Robot Blocker
 function parseUserAgentBlacklist() {
    var userAgentBlacklist = [/OPBot/, /BrightEdge/];
    var autoRun = true;

    userAgentBlacklist.forEach(function(userAgentRegex) {
    if (window.navigator.userAgent.match(userAgentRegex)) {
        autoRun = false;
        return;
    }
    });

    return autoRun;
}

options.autoRun = parseUserAgentBlacklist();

//identify the appropriate campaign
var invCampaignID = "other_unknown";
if(Invoca.Tools.readCookie("sourcecode")){
  invCampaignID = decodeURIComponent(Invoca.Tools.readCookie("sourcecode"));
}

 //Invoca Number Placing Function
options.numberSelector = ".invTelNum"; //Make sure to fill this string in with the span class of the phone number location

//Ensure affiliates are placed into their own campaign for web reporting features for Invoca.  Soucecode tracking is fine.
if((invCampaignID.indexOf('affiliate') > -1) || (invCampaignID.indexOf('perform_media') > -1)){
  options.defaultCampaignId = invCampaignID;
}

//Ensure Healthgrades can see doctor.com platform calls.
else if (invCampaignID.indexOf('local_search_doctor_com') > -1){
  options.defaultCampaignId = 'local_search_doctor_com';
}

//Rio Campaigns
else if(invCampaignID.indexOf('local_search_rioseo_atlanta') > -1){options.defaultCampaignId = 'local_search_rioseo_atlanta';}
else if(invCampaignID.indexOf('local_search_rioseo_boca') > -1){options.defaultCampaignId = 'local_search_rioseo_boca';}
else if(invCampaignID.indexOf('local_search_rioseo_chicago') > -1){options.defaultCampaignId = 'local_search_rioseo_chicago';}
else if(invCampaignID.indexOf('local_search_rioseo_downtown_chicago') > -1){options.defaultCampaignId = 'local_search_rioseo_downtown_chicago';}
else if(invCampaignID.indexOf('local_search_rioseo_gilbert') > -1){options.defaultCampaignId = 'local_search_rioseo_gilbert';}
else if(invCampaignID.indexOf('local_search_rioseo_gurnee') > -1){options.defaultCampaignId = 'local_search_rioseo_gurnee';}
else if(invCampaignID.indexOf('local_search_rioseo_north_phoenix') > -1){options.defaultCampaignId = 'local_search_rioseo_north_phoenix';}
else if(invCampaignID.indexOf('local_search_rioseo_philadelphia') > -1){options.defaultCampaignId = 'local_search_rioseo_philadelphia';}
else if(invCampaignID.indexOf('local_search_rioseo_phoenix') > -1){options.defaultCampaignId = 'local_search_rioseo_phoenix';}
else if(invCampaignID.indexOf('local_search_rioseo_scottsdale') > -1){options.defaultCampaignId = 'local_search_rioseo_scottsdale';}
else if(invCampaignID.indexOf('local_search_rioseo_tulsa') > -1){options.defaultCampaignId = 'local_search_rioseo_tulsa';}

//Yelp Campaigns
else if(invCampaignID.indexOf('local_search_yelp_atlanta') > -1){options.defaultCampaignId = 'local_search_yelp_atlanta';}
else if(invCampaignID.indexOf('local_search_yelp_chicago') > -1){options.defaultCampaignId = 'local_search_yelp_chicago';}
else if(invCampaignID.indexOf('local_search_yelp_downtown_chicago') > -1){options.defaultCampaignId = 'local_search_yelp_downtown_chicago';}
else if(invCampaignID.indexOf('local_search_yelp_gurnee') > -1){options.defaultCampaignId = 'local_search_yelp_gurnee';}
else if(invCampaignID.indexOf('local_search_yelp_philadelphia') > -1){options.defaultCampaignId = 'local_search_yelp_philadelphia';}
else if(invCampaignID.indexOf('local_search_yelp_phoenix') > -1){options.defaultCampaignId = 'local_search_yelp_phoenix';}
else if(invCampaignID.indexOf('local_search_yelp_gilbert') > -1){options.defaultCampaignId = 'local_search_yelp_gilbert';}
else if(invCampaignID.indexOf('local_search_yelp_north_phoenix') > -1){options.defaultCampaignId = 'local_search_yelp_north_phoenix';}
else if(invCampaignID.indexOf('local_search_yelp_scottsdale') > -1){options.defaultCampaignId = 'local_search_yelp_scottdale';}
else if(invCampaignID.indexOf('local_search_yelp_tulsa') > -1){options.defaultCampaignId = 'local_search_yelp_tulsa';}


//High Priority Queue
else if (
      (
        ((invCampaignID.indexOf('branded_natural_search')>-1) || (invCampaignID.indexOf('branded_paid_search') > -1 )) &&
        (invCampaignID.indexOf('non_branded_natural_search')==-1) && (invCampaignID.indexOf('non_branded_paid_search') == -1 )
      )
      ||
      (invCampaignID.indexOf('paid_search_google_national_brand')>-1) 
      || 
      (invCampaignID.indexOf('paid_search_microsoft_national_brand')>-1)
    ){
  options.defaultCampaignId = 'high_priority'; 

}

else if((invCampaignID === "test") || (invCampaignID === "test_routing")){
    options.defaultCampaignId = invCampaignID;
}
else{
  options.defaultCampaignId = 'other_unknown';
}

options.onComplete = fadeNumber;

return options;
  };

  return true;
})();

var generatedOptions = {
  autoSwap:            false,
  cookieDays:          cacheLifetimeDays,
  country:             null,
  defaultCampaignId:   defaultCampaignId,
  destinationSettings: destinationSettings,
  disableUrlParams:    ['batch_event_id','call_endpoint','mcid','media_channels','sourcecode_type'],
  doNotSwap:           [],
  maxWaitFor:          waitFor,
  networkId:           networkId || null,
  numberToReplace:     numbersToReplace,
  organicSources:      organicSources,
  poolParams:          {},
  reRunAfter:          reRunAfter,
  requiredParams:      requiredParams,
  resetCacheOn:        resetCacheOn,
  waitForData:         customDataWaitForConfig
};

Invoca.Client.startFromWizard(generatedOptions);

})(1169);
