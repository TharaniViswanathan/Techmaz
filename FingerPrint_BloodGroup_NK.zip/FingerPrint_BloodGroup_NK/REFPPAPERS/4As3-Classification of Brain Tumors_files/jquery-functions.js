// This is required to fix an issue in earlier versions of Windows Phone 8
// http://timkadlec.com/2013/01/windows-phone-8-and-device-width/
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement('style')
    msViewportStyle.appendChild(
      document.createTextNode(
        '@-ms-viewport{width:auto!important}'
      )
    )
    document.querySelector('head').appendChild(msViewportStyle)
};

var itemTimer;

/* ================================================================
   UTILITY CALLS FOR SITE
   ================================================================ */

(function ($, util, undefined) {
    "use strict";

    util.debounce = function (func, wait, immediate) {
        var timeout;
        return function () {
            var context = this, args = arguments;
            var later = function () {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    };

    util.getViewportW = window.getViewportW || function () {
        var win = typeof window != 'undefined' && window,
            doc = typeof document != 'undefined' && document,
            docElem = doc && doc.documentElement;

        var a = docElem.clientWidth, b = win.innerWidth;
        return a < b ? b : a;
    };

    util.a11yClick = function (event) {
        if (event.type === 'click' || event.type === 'touchstart') {
            return true;
        }
        else if (event.type === 'keypress') {
            var code = event.which || e.keyCode || 0;
            if (code === 32) {
                event.preventDefault();
            }
            if ((code === 32) || (code === 13)) {
                return true;
            }
        }
        else {
            return false;
        }
    };

    util.linkSecurity = function () {
        $("a[target=_blank]:not([rel='noopener noreferrer']), a[target=new]:not([rel='noopener noreferrer'])").attr("rel", "noopener noreferrer");
    };

    util.updateHeights1 = function () {
		$(".banners-container").each(function () {
			$(this).find(".heading-group").matchHeights();
		});		
    };

    util.setupToggles = function () {
        $("[data-toggle]:not([data-init])").each(function (key, val) {
            var $toggle = $(this),
                relatedData = $toggle.data("target"),
                toggleID = $toggle.attr("id"),
                isOverlay = $toggle.data("toggle") === "overlay" || false,
                isHold = $toggle.data("hold") || false;

            // POPOVER/DROPDOWN functionality
            function toggleControl() {
                // Clear out Toggle Handler for easy exit of toggle if it exists
                var $htmlTag = $("html");
                
                if (isOverlay) {
                    $htmlTag.removeClass("js-data-toggled");
                }
                
                $htmlTag.off("click touchstart keyup", dataToggleHandler);

                if ($toggle.hasClass("active")) {
                    //update a11y and classes, etc. if already opened
                    $toggle.removeClass("active").attr("aria-expanded", "false");
                    $controls.slideUp();
                } else {
                    // Set up attributes and classes for styling and a11y
                    $toggle.addClass("active").attr("aria-expanded","true");

                    $controls.slideDown(function () {
                        var $search = $(this);$

                        if ( isOverlay ) {
                            $htmlTag.addClass("js-data-toggled");
                        }

                        // Set up later timeout functionality to make sure we can clearout if other data toggles are pressed
                        var later = function () {
                            if ( $controls.find("input, select, textarea").length > 0 ) {
                                $controls.find("input, select, textarea").first().focus();
                            } else {
                                $controls.focus();
                            }
                        };

                        timeoutItem = setTimeout(later, 400);
                    });

                    // Set up Toggle Handler for easy exit of toggle
                    if ( isOverlay ) {
                        $htmlTag.addClass("js-data-toggled");
                    }

                    if ( ! isHold ) {
                        $htmlTag.on("click touchstart keyup", dataToggleHandler);
                    }
                }
            }

            //namespaced function for use in html event checks from above
            function dataToggleHandler(e) {
                var requiresTrigger = false;
                //Check if escape is keyup-ed 
                if ( e.which === 27 ) {
                    requiresTrigger = true;
                    $toggle.focus();
                } else {
                    //otherwise check if touch/click is outside of bounds
                    var $target = $(e.target);
                    if ( $target.closest("#" + relatedData).length <= 0 && $target.closest("#" + toggleID).length <= 0 ) {
                        requiresTrigger = true;
                    }
                }

                if (requiresTrigger) {
                    toggleControl();
                    //Clear timeout to help prevent focus / other data toggle press conflicts
                    clearTimeout(timeoutItem);
                    timeoutItem = null;
                }
            }

            // No point in doing anything if there isn't a proper related element set
            if ( relatedData ) {
                var $controls = $("#" + relatedData ),
                    timeoutItem = null;

                // make sure there is an ID set for the toggle for a11y needs
                if ( ! toggleID ) {
                    $toggle.attr("id", "data-toggle-" + key);
                    toggleID = $toggle.attr("id");
                }
                
                //Indicate initialization
                $toggle.attr("data-init", "");
                
                // finish up a11y setup for related element
                $controls.attr({ "aria-labelledby": toggleID });

                //Setup proper roles for a11y and then bind interaction functionality
                $toggle.attr({ "role":"button", "aria-haspopup": "true", "aria-expanded": "false" }).on("click keypress", function (e) {
                    if (util.a11yClick(e) === true) {
                        e.preventDefault();
                        //Call function that controls show/hide
                        toggleControl();
                    }
                });
            }
        });
    };

})(jQuery, window.aansUtil = window.aansUtil || {});



jQuery(function ($) {
	
	/* DATA TOGGLE INIT */
    aansUtil.setupToggles();
	
	/* MATCH HEIGHTS INIT */
	var windolWidth = aansUtil.getViewportW();	
	if ( windolWidth >= 768){
		aansUtil.updateHeights1();
	}
	
    // TOGGLES / EXPANDERS
    $(".expandable").on("click", ".trigger", function (event) {
        event.preventDefault();
        $(this).closest(".expandable").find(".hidden-content").toggleClass("open");
        $(this).closest(".expandable").toggleClass("open");
        event.stopPropagation();
    });
	
	/* NAVIGATIONS init and Clone Extra Navigation */
	$(".extra-navigation").children().each(function () {
        var $clone = $(this).clone();
        $clone.addClass("extra-link");
        $(".main-nav .cm-menu").append($clone);
    });
	$(".login-btn").children().each(function () {
        var $clone = $(this).clone();
        $clone.addClass("extra-link-alt");
        $(".main-nav .cm-menu").append($clone);
    });
	
	$(".main-nav").clickMenu();
	$(".section-nav").clickMenu({menutype:"accordion", expanders:true, isAutoClose:false});

	//detects keyboard/mouse user
    $("body").on("click", function () {
        var $html = $("html");
        if (!$html.hasClass("click-user")) {
            $html.removeClass("keyboard-user").addClass("click-user");
        }
    });

    $("body").on("keyup", function () {
        var $html = $("html");
        if (!$html.hasClass("keyboard-user")) {
            $html.removeClass("click-user").addClass("keyboard-user");
        }
    });

	//adds noopener noreferrer to all target=""_blank" links
	$("a[target=_blank], a[target=new]").attr("rel", "noopener noreferrer");

	//hides broken images
	$('img:not([src]), img[src=""]').addClass("visually-hidden");

	// Slideshow
	$('.slideshow-home').slick({
		infinite: true,
		autoplay: true,
		autoplaySpeed: 10000,
		arrows: false,
		dots: true
	});

    $(".truncate").truncate({
        max_length: 400,
        more: "read more",
        less: "read less"
    });

    // dialog windows
    $(".uiModal").dialog({
        autoOpen: false,
        width: "720px",
        bgiframe: true,
        modal: true,
        resizable: false,
        live: false,
        buttons: {
            Close: function () {
                $(this).dialog("close");
            }
        }
    });

    $(".uiDialog").dialog({
        autoOpen: false,
        width: "720px",
        bgiframe: true,
        modal: false,
        resizable: false,
        buttons: {
            Close: function () {
                $(this).dialog("close");
            }
        }
    });

    //AANS Accordian
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].onclick = function () {
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        }
    }

    // END dialog windows

    // carousels
    /* This was moved to /cms/includes/js/modules/carouselScrollable.js
    $('div.carousel div.scrollable').each(function () {
        //var size = parseFloat($(this).parent().attr('class').split(' ').slice(-1).join().substring(11));
        var size = parseFloat($(this).attr('class').match(/\d\b/g));

        var $carousel = $(this).scrollable({
            size: size,
            items: ".items",
            clickable: false
        });

        var $items = $(this).children(':first').children().matchHeights();
        if ($items.length > size) { $(this).parent().find(".nextPage").removeClass('disabled'); };

        var itemHeight = $items.outerHeight();
        $(this).css({ 'height': itemHeight }).nextAll().each(function () {
            $(this).css({ 'top': (itemHeight - $(this).height()) / 2 });
        });
    });
    */
    // END carousels

    $(".tabModule").tabs();
    $(".mod_landing_gal li").matchHeights();




    //EP - Fix for Webkit issue with AjaxControlToolkit
    if (typeof Sys != 'undefined') { Sys.Browser.WebKit = {}; if (navigator.userAgent.indexOf('WebKit/') > -1) { Sys.Browser.agent = Sys.Browser.WebKit; Sys.Browser.version = parseFloat(navigator.userAgent.match(/WebKit\/(\d+(\.\d+)?)/)[1]); Sys.Browser.name = 'WebKit'; } }
});

$( document ).ready(function() {
    var data = $('p:contains("John (Jack) LeRoy Moriarity, Jr., MD")');
    data.parent().remove();

    var data2 = $('p:contains("David Estin, MD, FAANS")');
    data2.parent().remove();

    var data3 = $('p:contains("Michael Joseph Caron, MD, FAANS")');
    data3.text("Drs. Michael and Theresa Caron");


    var date = new Date().getFullYear();
    var item = $('.current-year');
    item.text(date);

});