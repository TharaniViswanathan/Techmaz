(function (w) {
    
        
    if (typeof w.feathr === 'function') {
        w.feathr('integrate', 'ttd', '620cd1313d28830009a186f1');
    }
        
        
    if (typeof w.feathr === 'function') {
        w.feathr('match', '620cd1313d28830009a186f1');
    }
        
    
}(window));