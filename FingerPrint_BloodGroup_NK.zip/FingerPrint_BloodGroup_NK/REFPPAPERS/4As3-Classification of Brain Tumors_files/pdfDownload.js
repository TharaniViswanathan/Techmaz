// PDF Autodownload
$( document ).ready(function() {
	var download = GetURLParameter('download');
if(download == "yes"){
	xepOnline.Formatter.Format('JSFiddle',{render:'download',filename:'AANSPatientPDF',pageWidth:'10.6in',pageHeight:"13.7in"});
}
});
					

function GetURLParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

