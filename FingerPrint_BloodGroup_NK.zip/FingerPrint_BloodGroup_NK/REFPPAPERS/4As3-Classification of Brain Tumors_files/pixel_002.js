(function (w) {
    
}(window));